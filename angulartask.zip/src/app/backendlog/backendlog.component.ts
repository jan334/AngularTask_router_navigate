import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-backendlog',
  templateUrl: './backendlog.component.html',
  styleUrls: ['./backendlog.component.css']
})
export class BackendlogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
